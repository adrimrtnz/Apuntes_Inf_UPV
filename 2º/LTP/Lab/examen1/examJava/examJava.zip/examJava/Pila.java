
/**
 * Write a description of class Pila here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public interface Pila<T> extends Coleccion
{
    T cima();
    T desapilar();
}
