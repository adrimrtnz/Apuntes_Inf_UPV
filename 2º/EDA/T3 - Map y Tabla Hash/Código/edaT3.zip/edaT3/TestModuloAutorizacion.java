package ejemplos.tema3;
import librerias.excepciones.*;

public class TestModuloAutorizacion {

    public static void main(String[] args) throws Exception {
        ModuloAutorizacion mA = new ModuloAutorizacion(10);
        // COMPLETAR
        mA.registrarUsuario( ...
        mA.registrarUsuario( ...
        
        Thread.sleep(8000);
        
        // COMPLETAR
        System.out.println(mA.estaAutorizado( ...
        System.out.println(mA.estaAutorizado( ...
        
        // COMPLETAR
        System.out.println(mA.fechaAcceso( ...
        System.out.println(mA.fechaAcceso( ...
    }
}